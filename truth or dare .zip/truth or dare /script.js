// script.js
document.addEventListener('DOMContentLoaded', function() {
    // Page navigation
    const pages = document.querySelectorAll('.page');
    const navLinks = document.querySelectorAll('.nav-link');
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinksContainer = document.querySelector('.nav-links');
    
    // Game state
    let gameState = {
        players: [],
        currentPlayerIndex: 0,
        playerCount: 1
    };
    
    // Initialize the game
    init();
    
    function init() {
        // Set up event listeners
        setupNavigation();
        setupPlayerSelection();
        setupGameControls();
        setupMenuToggle();
    }
    
    function setupNavigation() {
        // Navigation links
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const pageId = this.getAttribute('data-page') + '-page';
                showPage(pageId);
                
                // Close mobile menu if open
                navLinksContainer.classList.remove('active');
            });
        });
        
        // Back buttons
        const backButtons = document.querySelectorAll('.back-btn');
        backButtons.forEach(button => {
            button.addEventListener('click', function() {
                showPage('welcome-page');
            });
        });
        
        // Home button
        const homeBtn = document.getElementById('home-btn');
        if (homeBtn) {
            homeBtn.addEventListener('click', function() {
                showPage('welcome-page');
            });
        }
        
        // Play again button
        const playAgainBtn = document.getElementById('play-again-btn');
        if (playAgainBtn) {
            playAgainBtn.addEventListener('click', function() {
                if (gameState.playerCount > 1) {
                    showPage('setup-page');
                    generatePlayerInputs(gameState.playerCount);
                } else {
                    startGame();
                }
            });
        }
    }
    
    function setupMenuToggle() {
        // Mobile menu toggle
        if (menuToggle) {
            menuToggle.addEventListener('click', function() {
                navLinksContainer.classList.toggle('active');
            });
        }
    }
    
    function setupPlayerSelection() {
        // Player selection buttons
        const playerButtons = document.querySelectorAll('.player-btn');
        playerButtons.forEach(button => {
            button.addEventListener('click', function() {
                const playerCount = parseInt(this.getAttribute('data-players'));
                gameState.playerCount = playerCount;
                
                if (playerCount > 1) {
                    showPage('setup-page');
                    generatePlayerInputs(playerCount);
                } else {
                    // Single player - use default name
                    gameState.players = ['Player 1'];
                    startGame();
                }
            });
        });
        
        // Start game button
        const startGameBtn = document.getElementById('start-game-btn');
        if (startGameBtn) {
            startGameBtn.addEventListener('click', function() {
                const playerInputs = document.querySelectorAll('.player-input input');
                gameState.players = [];
                
                playerInputs.forEach(input => {
                    const name = input.value.trim() || input.placeholder;
                    gameState.players.push(name);
                });
                
                startGame();
            });
        }
    }
    
    function setupGameControls() {
        // Truth and Dare buttons
        const truthBtn = document.querySelector('.truth-btn');
        const dareBtn = document.querySelector('.dare-btn');
        
        if (truthBtn) {
            truthBtn.addEventListener('click', function() {
                generateChallenge('truth');
            });
        }
        
        if (dareBtn) {
            dareBtn.addEventListener('click', function() {
                generateChallenge('dare');
            });
        }
        
        // Next player button
        const nextPlayerBtn = document.getElementById('next-player-btn');
        if (nextPlayerBtn) {
            nextPlayerBtn.addEventListener('click', function() {
                nextPlayer();
            });
        }
        
        // End game button
        const endGameBtn = document.getElementById('end-game-btn');
        if (endGameBtn) {
            endGameBtn.addEventListener('click', function() {
                showPage('gameover-page');
            });
        }
    }
    
    function generatePlayerInputs(playerCount) {
        const playerInputsContainer = document.querySelector('.player-inputs');
        playerInputsContainer.innerHTML = '';
        
        for (let i = 1; i <= playerCount; i++) {
            const inputDiv = document.createElement('div');
            inputDiv.className = 'player-input';
            
            const label = document.createElement('label');
            label.textContent = `Player ${i} Name:`;
            label.htmlFor = `player-${i}`;
            
            const input = document.createElement('input');
            input.type = 'text';
            input.id = `player-${i}`;
            input.placeholder = `Player ${i}`;
            
            inputDiv.appendChild(label);
            inputDiv.appendChild(input);
            playerInputsContainer.appendChild(inputDiv);
        }
    }
    
    function startGame() {
        gameState.currentPlayerIndex = 0;
        showPage('game-page');
        updateTurnIndicator();
        resetChallengeCard();
    }
    
    function updateTurnIndicator() {
        const currentPlayerElement = document.querySelector('.current-player');
        if (currentPlayerElement) {
            currentPlayerElement.textContent = gameState.players[gameState.currentPlayerIndex];
        }
    }
    
    function generateChallenge(type) {
        const challengeCard = document.querySelector('.challenge-card');
        const challengeType = document.querySelector('.challenge-type');
        const challengeText = document.querySelector('.challenge-text');
        const challengeCategory = document.querySelector('.challenge-category');
        
        // Get a random challenge based on type
        const challenges = type === 'truth' ? truthQuestions : dareChallenges;
        const randomIndex = Math.floor(Math.random() * challenges.length);
        const challenge = challenges[randomIndex];
        
        // Update challenge card
        challengeType.textContent = type.charAt(0).toUpperCase() + type.slice(1);
        challengeText.textContent = challenge.text;
        challengeCategory.textContent = `Category: ${challenge.category}`;
        
        // Flip the card with animation
        challengeCard.classList.add('flipped');
        
        // Disable truth/dare buttons after selection
        document.querySelector('.truth-btn').disabled = true;
        document.querySelector('.dare-btn').disabled = true;
    }
    
    function nextPlayer() {
        // Move to next player
        gameState.currentPlayerIndex = (gameState.currentPlayerIndex + 1) % gameState.players.length;
        
        // Update UI
        updateTurnIndicator();
        resetChallengeCard();
        
        // Re-enable buttons
        document.querySelector('.truth-btn').disabled = false;
        document.querySelector('.dare-btn').disabled = false;
    }
    
    function resetChallengeCard() {
        const challengeCard = document.querySelector('.challenge-card');
        challengeCard.classList.remove('flipped');
        
        // Reset challenge text after animation completes
        setTimeout(() => {
            const challengeText = document.querySelector('.challenge-text');
            challengeText.textContent = 'Choose Truth or Dare to begin!';
            
            const challengeType = document.querySelector('.challenge-type');
            challengeType.textContent = '';
            
            const challengeCategory = document.querySelector('.challenge-category');
            challengeCategory.textContent = '';
        }, 300);
    }
    
    function showPage(pageId) {
        // Hide all pages
        pages.forEach(page => {
            page.classList.remove('active');
        });
        
        // Show the requested page
        const targetPage = document.getElementById(pageId);
        if (targetPage) {
            targetPage.classList.add('active');
        }
        
        // Scroll to top
        window.scrollTo(0, 0);
    }
    
    // Share functionality for support page
    const shareButtons = document.querySelectorAll('.support-option button');
    shareButtons.forEach((button, index) => {
        button.addEventListener('click', function() {
            if (index === 0) {
                // Share on social media
                if (navigator.share) {
                    navigator.share({
                        title: 'Truth or Dare Online',
                        text: 'Check out this fun Truth or Dare game!',
                        url: window.location.href
                    })
                    .catch(error => {
                        console.log('Error sharing:', error);
                    });
                } else {
                    alert('Share this link with your friends: ' + window.location.href);
                }
            } else if (index === 1) {
                // Donate
                alert('Thank you for your support! Donation functionality would be implemented here.');
            } else if (index === 2) {
                // Feedback
                alert('Feedback form would open here.');
            }
        });
    });
});